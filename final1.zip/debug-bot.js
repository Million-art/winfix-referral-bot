const fs = require('fs');
const path = require('path');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir);
}

/**
 * Log bot activity to a file for debugging
 * @param {String} type - Type of log entry
 * @param {Object} data - Data to log
 */
function logBotActivity(type, data) {
    const logFile = path.join(logsDir, `bot-debug-${new Date().toISOString().slice(0, 10)}.log`);
    
    const logEntry = {
        timestamp: new Date().toISOString(),
        type: type,
        data: data
    };
    
    fs.appendFileSync(logFile, JSON.stringify(logEntry, null, 2) + ',\n');
}

module.exports = {
    logBotActivity
}; 