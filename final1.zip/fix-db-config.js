const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '.env') });
const { config } = require('./config/config');

console.log('Current database configuration:');
console.log('------------------------------');
console.log('Database name:', config.db.name || 'NOT SET');
console.log('Username:', config.db.user || 'NOT SET');
console.log('Password:', config.db.password ? '(HIDDEN)' : 'NOT SET');
console.log('Host:', config.db.host || 'NOT SET');
console.log('Dialect:', config.db.dialect || 'NOT SET');

// The issue is likely that USER is a reserved environment variable in Windows
// Let's fix the db_config.js file to use a different variable name for database user
const fs = require('fs');

// Path to original file
const configFilePath = path.join(__dirname, 'config', 'config.js');
const content = fs.readFileSync(configFilePath, 'utf8');

// Create modified content
const updatedContent = content.replace(
  /user: process.env.USER/g, 
  'user: process.env.DB_USER || process.env.USER'
);

// Write updated content to file
fs.writeFileSync(configFilePath, updatedContent);
console.log('\nFixed config/config.js to use DB_USER as an alternative to USER');

// Now update .env file to use DB_USER instead of USER
console.log('\nYour next steps:');
console.log('1. Add DB_USER=root to your .env file');
console.log('2. Ensure you have PASSWORD= in your .env file if your MySQL has no password');
console.log('3. Run your application again with: node app.js'); 