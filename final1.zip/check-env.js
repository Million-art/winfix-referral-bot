const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '.env') });

console.log('Checking environment variables:');

const requiredVars = [
  'BOT_TOKEN',
  'DATABASE',
  'USER',
  'PASSWORD',
  'HOST',
  'CHANNEL_ID',
  'BOT_URL',
  'CARD_IMAGE_URL',
  'ADMIN_ID',
  'CHANNEL_URL'
];

let missing = [];
let present = [];

requiredVars.forEach(key => {
  if (process.env[key]) {
    present.push(key);
  } else {
    missing.push(key);
  }
});

console.log('Present:', present.join(', '));
console.log('Missing:', missing.join(', ')); 