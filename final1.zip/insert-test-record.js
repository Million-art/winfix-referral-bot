const { sequelize, User, ThisWeekWinner } = require('./models');

async function insertTestRecord() {
  try {
    console.log('Connecting to database...');
    await sequelize.authenticate();
    console.log('Connection established successfully.');

    // Step 1: Ensure the user exists
    const userId = 386095768; // Your test user ID
    console.log(`Ensuring user ${userId} exists...`);
    const [user, userCreated] = await User.findOrCreate({
      where: { telegram_id: userId },
      defaults: {
        telegram_id: userId,
        first_name: 'Test User',
        username: 'testuser',
        left: false
      }
    });

    console.log(`User ${userId} ${userCreated ? 'created' : 'already exists'}.`);

    // Step 2: Insert test record
    console.log('Inserting test record into this_week_winners...');
    const data = {
      telegram_id: userId,
      first_name: 'Test User',
      referral_count: 5,
      website: 've777.club',
      web_username: 'testusername',
      created_at: new Date()
    };

    const [winner, created] = await ThisWeekWinner.upsert(data, {
      returning: true
    });

    console.log(`Record ${created ? 'created' : 'updated'}:`, winner.toJSON());

    // Step 3: Verify insertion
    console.log('\nVerifying insertion...');
    const verification = await ThisWeekWinner.findOne({
      where: { telegram_id: userId }
    });
    
    if (!verification) {
      console.log('Verification failed: Record not found after insertion!');
    } else {
      console.log('Verification successful:', verification.toJSON());
    }
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await sequelize.close();
  }
}

insertTestRecord(); 