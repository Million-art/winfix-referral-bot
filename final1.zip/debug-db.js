const { sequelize, ThisWeekWinner } = require('./models');

async function testDatabaseOperations() {
    try {
        // Test database connection
        await sequelize.authenticate();
        console.log('Database connection has been established successfully.');

        // Test data
        const testData = {
            telegram_id: 123456789,
            first_name: "Test User",
            referral_count: 5,
            website: "winfix.live",
            web_username: "testuser",
            created_at: new Date()
        };

        console.log('Attempting to insert test data:', testData);

        // Try to insert using create
        const created = await ThisWeekWinner.create(testData);
        console.log('Insert successful:', created.toJSON());

        // Try to fetch the data
        const found = await ThisWeekWinner.findOne({
            where: { telegram_id: 123456789 }
        });
        console.log('Retrieved data:', found ? found.toJSON() : 'Not found');

        // List all records
        const all = await ThisWeekWinner.findAll();
        console.log('All records:', all.map(record => record.toJSON()));

    } catch (error) {
        console.error('Error occurred:', error);
        console.error('Detailed error:', {
            name: error.name,
            message: error.message,
            stack: error.stack,
            original: error.original
        });
    } finally {
        await sequelize.close();
    }
}

testDatabaseOperations(); 