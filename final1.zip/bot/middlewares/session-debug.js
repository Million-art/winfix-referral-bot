const { logBotActivity } = require('../../debug-bot');

/**
 * Middleware to debug session data
 * @param {Object} ctx - Telegram context
 * @param {Function} next - Next middleware
 */
async function sessionDebugMiddleware(ctx, next) {
    // Log initial session state
    logBotActivity('session_debug', {
        updateType: ctx.updateType,
        userId: ctx.from?.id,
        hasSession: !!ctx.session,
        sessionData: ctx.session,
        updateId: ctx.update?.update_id,
        messageId: ctx.message?.message_id,
        callbackQuery: ctx.callbackQuery?.data
    });
    
    // Continue processing
    await next();
    
    // Log session state after processing
    logBotActivity('session_after_processing', {
        updateType: ctx.updateType,
        userId: ctx.from?.id,
        hasSession: !!ctx.session,
        sessionData: ctx.session,
        updateId: ctx.update?.update_id,
        messageId: ctx.message?.message_id,
        callbackQuery: ctx.callbackQuery?.data
    });
}

module.exports = sessionDebugMiddleware; 