/**
 * User command handlers for the bot
 * Includes my_referral, rules, leaderboard
 */
const { countMyWeeklyReferrals, getCurrentLeaderboard } = require('../../services/user.js');
const { MIN_REFERRAL_COUNT } = require('../../constants.js');
const { processUserWebsiteSubmission } = require('../../services/userService');
const { logBotActivity } = require('../../debug-bot.js');

/**
 * Sets up all user command handlers
 * @param {Object} bot - Telegraf bot instance
 */
function setupUserHandlers(bot) {
  // Command: /my_referral - Shows user's referral stats
  bot.command('my_referral', async (ctx) => {
    try {
      // Call the stats function
      await countMyWeeklyReferrals(ctx);
    } catch (err) {
      console.error("Error sending referral stats:", err);
      await ctx.reply("❌ Something went wrong.");
    }
  });
  
  // Command: /rules - Shows rules and regulations
  bot.command('rules', async (ctx) => {
    const rulesMessage = `
📜 *Rules and Regulations for Referral System*

1. *Referral Process*
   - Share your unique referral link with friends
   - Friends must join the channel through your link
   - Friends must remain in the channel to count as valid referrals

2. *Valid Referrals*
   - Only users who are active members of the channel count
   - If a referred user leaves the channel, they no longer count
   - You cannot refer yourself
   - Each user can only be referred once

3. *Qualification Requirements*
   - Minimum ${MIN_REFERRAL_COUNT} valid referrals required to qualify
   - All referrals must be active channel members
   - Referrals are validated when you submit your username

4. *Reward Process*
   - Once you qualify, you'll be asked to select your website
   - Provide your correct username for the selected website
   - Rewards are processed after validation
`;

    await ctx.reply(rulesMessage, { parse_mode: 'Markdown' });
  });
  
  // Command: /leaderboard - Shows current monthly leaders
  bot.command('leaderboard', async (ctx) => {
    try {
      // Show typing indicator
      await ctx.sendChatAction('typing');
      
      // Get top 3 leaders
      const leaders = await getCurrentLeaderboard(ctx);
      
      if (leaders.length === 0) {
        return ctx.reply("No active referrals yet. Be the first to refer someone!");
      }

      // Build simple leaderboard message
      let message = "🏆 Top 3 Referrers:\n\n";
      const medals = ["🥇", "🥈", "🥉"];
      
      leaders.slice(0, 3).forEach((leader, index) => {
        message += `${medals[index]} ${leader.first_name} - ${leader.referral_count} referrals\n`;
      });

      await ctx.reply(message);

    } catch (error) {
      console.error("Leaderboard error:", error);
      await ctx.reply("Failed to load leaderboard. Please try again later.");
    }
  });

  // Command: /ask_username - Collects user's website and username
  bot.command('ask_username', async (ctx) => {
    try {
      logBotActivity('ask_username_command', {
        from: ctx.from,
        message: ctx.message
      });

      // Create inline keyboard with website options
      const keyboard = {
        inline_keyboard: [
          [
            { text: 'winfix.live', callback_data: 'website_winfix.live' },
            { text: 'autoexch.live', callback_data: 'website_autoexch.live' }
          ],
          [
            { text: 've567.live', callback_data: 'website_ve567.live' },
            { text: 've777.club', callback_data: 'website_ve777.club' }
          ],
          [
            { text: 'vikrant247.com', callback_data: 'website_vikrant247.com' }
          ]
        ]
      };

      await ctx.reply(
        "Please select your website platform:",
        { reply_markup: keyboard }
      );
    } catch (error) {
      console.error("Error in ask_username:", error);
      logBotActivity('ask_username_error', {
        error: {
          message: error.message,
          stack: error.stack
        }
      });
      await ctx.reply("❌ An error occurred. Please try again later.");
    }
  });
  
  // Handle text messages for username submission
  setupUsernameSubmissionHandler(bot);
}

/**
 * Sets up the text message handler for username submissions
 * @param {Object} bot - Telegraf bot instance
 */
function setupUsernameSubmissionHandler(bot) {
  bot.on('text', async (ctx) => {
    const userId = ctx.from.id;
    
    // Skip command messages
    if (ctx.message.text.startsWith('/')) {
      return;
    }
    
    // Get selection from state
    const pendingSelection = ctx.state.pendingSelections?.get(userId);
    
    logBotActivity('text_message', {
      userId: userId,
      message: ctx.message,
      hasSelection: !!pendingSelection,
      pendingSelection: pendingSelection
    });
    
    // Only process if this user has a pending selection
    if (pendingSelection && pendingSelection.website) {
      console.log('Username message received:', ctx.message.text);
      console.log('User info:', {
        id: userId,
        first_name: ctx.from.first_name,
        username: ctx.from.username
      });
      
      const username = ctx.message.text.trim();
      const website = pendingSelection.website;
      
      logBotActivity('processing_username', {
        userId: userId,
        username: username,
        website: website,
        pendingSelection: pendingSelection
      });
      
      console.log('Username submitted:', username);
      console.log('Selected website:', website);

      try {
        // Process the submission
        const result = await processUserWebsiteSubmission(ctx, website, username);
        console.log('processUserWebsiteSubmission result:', result);
        
        logBotActivity('submission_result', {
          userId: userId,
          result: result,
          username: username,
          website: website
        });
        
        // Clear the pending selection only if successful
        if (result) {
          console.log(`Clearing pending selection for user ${userId}`);
          ctx.state.pendingSelections.delete(userId);
        }
        
      } catch (error) {
        console.error("Error processing username submission:", error);
        logBotActivity('submission_error', {
          userId: userId,
          error: {
            message: error.message,
            stack: error.stack
          },
          username: username,
          website: website
        });
        await ctx.reply("❌ An error occurred while processing your submission. Please try again later.");
      }
    }
  });
}

module.exports = setupUserHandlers; 