/**
 * Database configuration and connection setup
 */
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const { Sequelize } = require('sequelize');
const { config } = require('./config');
const logger = require('../utils/logger');

// Log the actual database configuration to help debug the issue
console.log('Database connection details:');
console.log('- Database name:', config.db.name);
console.log('- Database user:', config.db.user || 'NOT SET');
console.log('- Database host:', config.db.host);
console.log('- Using password:', config.db.password ? 'YES' : 'NO');

const env = process.env.NODE_ENV || 'development';
const sequelizeConfig = require('./sequelize-cli')[env];

/**
 * Creates a Sequelize instance with optimized configuration
 */
const sequelize = new Sequelize({
  ...sequelizeConfig,
  logging: (msg) => logger.debug(msg),
  pool: {
    max: 20,            // Maximum number of connection in pool
    min: 5,             // Minimum number of connection in pool
    acquire: 30000,     // Maximum time (ms) to acquire a connection
    idle: 10000         // Maximum time (ms) a connection can be idle before being released
  },
  retry: {
    max: 3,             // Maximum retries for failed queries
    match: [            // Retry only these errors
      /Deadlock/i,
      /SequelizeConnectionError/,
      /SequelizeConnectionRefusedError/,
      /SequelizeHostNotFoundError/,
      /SequelizeHostNotReachableError/,
      /SequelizeInvalidConnectionError/,
      /SequelizeConnectionTimedOutError/
    ]
  },
  benchmark: env !== 'production',  // Log query execution time in non-production
  dialectOptions: {
    connectTimeout: 60000, // Longer connection timeout
    ssl: sequelizeConfig.dialectOptions?.ssl || null
  },
  timezone: '+00:00'    // Set timezone for consistent datetime handling
});

// Test the connection on startup but don't exit on failure
sequelize.authenticate()
  .then(() => logger.info('Database connection established successfully'))
  .catch(err => {
    logger.error('Unable to connect to the database:', err);
    // Don't exit process here - allow app to handle reconnection
  });

module.exports = sequelize;