/**
 * Configuration module for the application
 * Validates and manages environment variables
 */

const path = require('path');

// Load environment variables from .env file
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

// Required environment variables with descriptions
const requiredEnvVars = {
    BOT_TOKEN: 'Telegram Bot Token',
    DATABASE: 'Database Name',
    USER: 'Database Username',
    PASSWORD: 'Database Password',
    HOST: 'Database Host',
    CHANNEL_ID: 'Telegram Channel ID',
    BOT_URL: 'Bot URL (e.g., https://t.me/your_bot)',
    CARD_IMAGE_URL: 'Referral Card Image URL',
    ADMIN_ID: 'Admin Telegram ID',
    CHANNEL_URL: 'Channel URL'
};

/**
 * Validates that all required environment variables are present
 * @throws {Error} If any required variables are missing
 */
function validateEnv() {
    // For development mode, don't validate environment variables
    if (process.env.NODE_ENV !== 'production') {
        console.warn('Running in development mode - skipping strict env validation');
        
        // Set default values for missing variables
        if (!process.env.BOT_TOKEN) process.env.BOT_TOKEN = '8095395121:AAHRT-KuIKJfCRet-J9RVeRmXHeqRMpMCqI';
        if (!process.env.ADMIN_ID) process.env.ADMIN_ID = '386095768';
        if (!process.env.CHANNEL_ID) process.env.CHANNEL_ID = '-1001190544004';
        if (!process.env.BOT_URL) process.env.BOT_URL = 'https://t.me/assaddsddaaaaaaaaaaaaaaaa_bot';
        if (!process.env.CARD_IMAGE_URL) process.env.CARD_IMAGE_URL = 'https://cdn.dribbble.com/userupload/13499309/file/original-23af3c8956046cf7d37a289c229fb4e2.png?resize=752x';
        if (!process.env.CHANNEL_URL) process.env.CHANNEL_URL = 'https://t.me/finance_et';
        if (!process.env.PASSWORD) process.env.PASSWORD = '';
        if (!process.env.DATABASE) process.env.DATABASE = 'bot_db';
        if (!process.env.USER) process.env.USER = 'root';
        if (!process.env.HOST) process.env.HOST = 'localhost';
        
        return;
    }
    
    // In production, strictly validate
    const missingVars = [];
    
    for (const [key, description] of Object.entries(requiredEnvVars)) {
        if (!process.env[key]) {
            missingVars.push(`${key} (${description})`);
        }
    }
    
    if (missingVars.length > 0) {
        throw new Error(
            'Missing required environment variables:\n' +
            missingVars.map(v => `- ${v}`).join('\n') + 
            '\n\nPlease set these variables in your .env file.'
        );
    }
}

// Sequelize configuration
const sequelizeConfig = {
    development: {
        username: process.env.USER || 'root',
        password: process.env.PASSWORD || '',
        database: process.env.DATABASE || 'bot_db',
        host: process.env.HOST || 'localhost',
        dialect: 'mysql',
        logging: console.log
    },
    test: {
        username: process.env.USER,
        password: process.env.PASSWORD,
        database: process.env.DATABASE,
        host: process.env.HOST,
        dialect: 'mysql',
        logging: false
    },
    production: {
        username: process.env.USER,
        password: process.env.PASSWORD,
        database: process.env.DATABASE,
        host: process.env.HOST,
        dialect: 'mysql',
        logging: false,
        dialectOptions: {
            ssl: process.env.DB_SSL === 'true' ? {
                require: true,
                rejectUnauthorized: false
            } : false
        }
    }
};

/**
 * Configuration object with defaults and environment variables
 */
const config = {
    bot: {
        token: process.env.BOT_TOKEN || '8095395121:AAHRT-KuIKJfCRet-J9RVeRmXHeqRMpMCqI',
        adminId: process.env.ADMIN_ID || "386095768",
        url: process.env.BOT_URL || 'https://t.me/assaddsddaaaaaaaaaaaaaaaa_bot',
        cardImageUrl: process.env.CARD_IMAGE_URL || 'https://cdn.dribbble.com/userupload/13499309/file/original-23af3c8956046cf7d37a289c229fb4e2.png?resize=752x'
    },
    db: {
        name: process.env.DATABASE || 'bot_db',
        user: process.env.DB_USER || process.env.USER || 'root',
        password: process.env.PASSWORD || '',
        host: process.env.HOST || 'localhost',
        dialect: 'mysql',
        ssl: process.env.DB_SSL === 'true'
    },
    telegram: {
        channelId: process.env.CHANNEL_ID || '-100123456789',
        channelUrl: process.env.CHANNEL_URL || 'https://t.me/example_channel',
        minReferralCount: parseInt(process.env.MIN_REFERRAL_COUNT || '0', 10)
    },
    server: {
        port: parseInt(process.env.PORT || '3000', 10),
        env: process.env.NODE_ENV || 'development',
        domain: process.env.DOMAIN || 'localhost'
    },
    security: {
        inputValidation: true,
        sanitizeUserInput: true
    },
    logging: {
        level: process.env.LOG_LEVEL || 'info'
    }
};

module.exports = { config, validateEnv, ...sequelizeConfig };