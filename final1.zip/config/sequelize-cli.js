const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

module.exports = {
  development: {
    username: process.env.USER || 'root',
    password: process.env.PASSWORD || '',
    database: 'bot_db',
    host: process.env.HOST || 'localhost',
    dialect: 'mysql'
  },
  test: {
    username: process.env.USER || 'root',
    password: process.env.PASSWORD || '',
    database: 'bot_db_test',
    host: process.env.HOST || 'localhost',
    dialect: 'mysql'
  },
  production: {
    username: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
    host: process.env.HOST,
    dialect: 'mysql',
    dialectOptions: {
      ssl: process.env.DB_SSL === 'true' ? {
        require: true,
        rejectUnauthorized: false
      } : false
    }
  }
}; 