const sequelize = require('../config/db_config');
const { config } = require('../config/config');
const logger = require('../utils/logger');
const { User, Referral } = require('../models');
const { joinChannelMarkup } = require('../helper/keyboard');
const { isRealUser } = require('../utils/userValidator');

/**
 * Generates a referral link for a user
 * @param {Object} ctx - Telegram context
 * @returns {string} - Referral link
 */
const getReferralLink = (ctx) => {
  return `${config.bot.url}?start=${ctx.from.id}`;
};

/**
 * Sends referral link to the user
 * @param {Object} ctx - Telegram context
 * @returns {Promise<void>}
 */
const sendReferralLink = async (ctx) => {
  try {
    logger.info(`Sending referral link to user ${ctx.from.id}`);
    
    const userReferralLink = getReferralLink(ctx);
    const imageCaption = `${require('../constants').REFERRAL_CAPTION}\n\n🔗 Your referral link:\n${userReferralLink}`;

    logger.debug("Sending photo with caption");
    
    // Validate the image URL before sending
    if (!config.bot.cardImageUrl || !config.bot.cardImageUrl.startsWith('http')) {
      throw new Error('Invalid card image URL configuration');
    }
    
    // Send with retry mechanism
    let attempt = 0;
    const maxAttempts = 3;
    let lastError;
    
    while (attempt < maxAttempts) {
      try {
        await ctx.replyWithPhoto(config.bot.cardImageUrl, {
          reply_markup: {
            inline_keyboard: [
              [{
                text: "Check how many users you referred",
                callback_data: "referred_users_number"
              }]
            ]
          },
          caption: imageCaption,
          parse_mode: "HTML" 
        });
        
        logger.info(`Successfully sent referral link to user ${ctx.from.id}`);
        return;
      } catch (error) {
        attempt++;
        lastError = error;
        logger.warn(`Attempt ${attempt} failed to send referral link:`, error.message);
        
        if (attempt < maxAttempts) {
          // Wait before retry (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
      }
    }
    
    // If we got here, all attempts failed
    logger.error(`Failed to send referral link after ${maxAttempts} attempts:`, lastError);
    throw new Error('Failed to send referral link after multiple attempts');
  } catch (error) {
    logger.error('Error sending referral link:', error);
    throw new Error('Failed to send referral link');
  }
};

/**
 * Registers a user with a referral number
 * @param {Object} ctx - Telegram context
 * @param {string} referralNum - Referral number
 * @returns {Promise<void>}
 */
const regUserWithReferralNumber = async (ctx, referralNum) => {
  // Validate referral number again
  if (!Number.isInteger(Number(referralNum))) {
    throw new Error("Invalid referral number format");
  }
  
  if (Number(referralNum) === Number(ctx.from.id)) {
    throw new Error("You cannot refer yourself.");
  }

  const transaction = await sequelize.transaction();
  try {
    logger.info(`Registering user ${ctx.from.id} with referral ${referralNum}`);
    
    // Get referrer's username and check if they've left
    const referrer = await User.findOne({
      where: { 
        telegram_id: referralNum,
        left: false  // Only allow referrals from active users
      },
      attributes: ['username'],
      transaction
    });

    if (!referrer) {
      await transaction.rollback();
      throw new Error("Referrer not found or has left the bot");
    }

    // Check if user is real based on our criteria
    const isReal = await isRealUser(ctx);
    logger.info(`User ${ctx.from.id} real status check: ${isReal}`);

    // Create or update user
    const [user] = await User.findOrCreate({
      where: { telegram_id: ctx.from.id },
      defaults: {
        first_name: ctx.from.first_name || 'Unknown',
        username: ctx.from.username || null,
        left: false
      },
      transaction
    });

    // If user exists and had left, update their status
    if (user && user.left) {
      await user.update({
        left: false,
        first_name: ctx.from.first_name || 'Unknown',
        username: ctx.from.username || null
      }, { transaction });
    }

    // Create referral record with real user validation
    await Referral.create({
      telegram_id: referralNum,
      referred_id: ctx.from.id,
      referred_username: ctx.from.username || null,
      referral_status: 'new',
      is_real_referral: isReal  // Set based on validation result
    }, { transaction });

    await transaction.commit();
    logger.info(`User ${ctx.from.id} registered with referral ${referralNum} (Real User: ${isReal})`);

    return ctx.reply(
      'Join the channel to complete the process:',
      { ...joinChannelMarkup, parse_mode: "HTML" }
    );
  } catch (error) {
    await transaction.rollback();
    logger.error('Referral registration error:', error);

    if (error.name === 'SequelizeUniqueConstraintError') {
      throw new Error("You have already been referred.");
    }
    throw new Error(error.message || "An error occurred. Please try again.");
  }
};

/**
 * Validates user referrals
 * @param {number} userId - User ID
 * @returns {Promise<boolean>}
 */
const validateUserReferrals = async (userId) => {
  try {
    const count = await Referral.count({
      where: { telegram_id: userId }
    });
    
    return count >= config.telegram.minReferralCount;
  } catch (error) {
    logger.error('Error validating referrals:', error);
    return false;
  }
};

module.exports = {
  getReferralLink,
  sendReferralLink,
  regUserWithReferralNumber,
  validateUserReferrals
};