// Load environment variables
console.log('Loading dotenv...');
require('dotenv').config();

console.log('Environment variables:');
console.log('USER:', process.env.USER || 'NOT SET');
console.log('DATABASE:', process.env.DATABASE || 'NOT SET');
console.log('HOST:', process.env.HOST || 'NOT SET');
console.log('BOT_TOKEN:', process.env.BOT_TOKEN || 'NOT SET');
console.log('CHANNEL_ID:', process.env.CHANNEL_ID || 'NOT SET');
console.log('BOT_URL:', process.env.BOT_URL || 'NOT SET');
console.log('CARD_IMAGE_URL:', process.env.CARD_IMAGE_URL || 'NOT SET');
console.log('ADMIN_ID:', process.env.ADMIN_ID || 'NOT SET');
console.log('CHANNEL_URL:', process.env.CHANNEL_URL || 'NOT SET');
console.log('PASSWORD:', process.env.PASSWORD ? 'SET (hidden)' : 'NOT SET');

// Special case: Windows environment has a USER variable by default
// Check if it might be the system USER variable
if (process.env.USER && process.env.USER.toLowerCase() !== 'root') {
  console.log('\nWARNING: USER appears to be the Windows system user, not the database user!');
  console.log('You may need to rename this to DB_USER in your .env file.');
} 