const { sequelize, WeeklyWinner } = require('./models');

async function checkWeeklyWinners() {
  try {
    console.log('Connecting to database...');
    await sequelize.authenticate();
    console.log('Connection established successfully.');

    console.log('\nChecking weekly_winners table...');
    const winners = await WeeklyWinner.findAll();
    
    if(winners.length === 0) {
      console.log('No records found in weekly_winners table.');
    } else {
      console.log(`Found ${winners.length} records:`);
      winners.forEach((winner, index) => {
        console.log(`\nRecord #${index + 1}:`);
        console.log(JSON.stringify(winner.toJSON(), null, 2));
      });
    }
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await sequelize.close();
  }
}

checkWeeklyWinners(); 