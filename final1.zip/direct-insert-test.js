const { sequelize, User, ThisWeekWinner } = require('./models');

async function testDirectInsert() {
    try {
        // Test database connection
        await sequelize.authenticate();
        console.log('Database connection established successfully.');

        // Step 1: Create a test user first
        const testUserId = 99999999; // A test telegram ID
        const [user, userCreated] = await User.findOrCreate({
            where: { telegram_id: testUserId },
            defaults: {
                telegram_id: testUserId,
                first_name: 'Test User',
                username: 'testuser',
                left: false
            }
        });

        console.log('User creation result:', {
            created: userCreated,
            user: user.toJSON()
        });

        // Step 2: Now try to insert into ThisWeekWinner
        const [winner, winnerCreated] = await ThisWeekWinner.upsert({
            telegram_id: testUserId,
            first_name: 'Test User',
            referral_count: 5,
            website: 'winfix.live',
            web_username: 'testusername',
            created_at: new Date()
        }, {
            returning: true
        });

        console.log('ThisWeekWinner upsert result:', {
            created: winnerCreated,
            winner: winner.toJSON()
        });

        // Step 3: Verify the data is in the database
        const verification = await ThisWeekWinner.findOne({
            where: { telegram_id: testUserId }
        });

        console.log('Verification result:', 
            verification ? verification.toJSON() : 'Not found'
        );

    } catch (error) {
        console.error('Error occurred:', error);
        console.error('Full error details:', {
            name: error.name,
            message: error.message,
            stack: error.stack,
            original: error.original
        });
    } finally {
        await sequelize.close();
    }
}

// Run the test
testDirectInsert(); 